﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MyNotePad
{
    public partial class NotePad_General : Form
    {
        public NotePad_General()
        {
            InitializeComponent();
        }

        private void button_open_Click(object sender, EventArgs e)
        {
            if (open_fd.ShowDialog() == DialogResult.Cancel)
            {
                label_operationStatus.Text = "Открытие файла отменено";
                return;
            }
            try
            {
                textBox_general.Text = File.ReadAllText(open_fd.FileName, Encoding.UTF8);
                label_operationStatus.Text = "Открытие файла прошло успешно";
            }
            catch
            {
                MessageBox.Show("Ошибка при открытии", "Ошибка");
            }
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            if (save_fd.ShowDialog() == DialogResult.Cancel)
            {
                label_operationStatus.Text = "Сохранение файла отменено";
                return;
            }
            try
            {
                File.WriteAllText(save_fd.FileName + ".txt", textBox_general.Text, Encoding.UTF8);
                label_operationStatus.Text = "Сохранение файла прошло успешно";
            }
            catch
            {
                MessageBox.Show("Ошибка при сохранении", "Ошибка");
                label_operationStatus.Text = "Ошибка при сохранении";
            }
        }

        private void button_replace_Click(object sender, EventArgs e)
        {
            if (textBox_general.Text == "")
            {
                label_operationStatus.Text = "Строк для замены не найдено!";
                return;
            }
            else
            {
                textBox_general.Text = textBox_general.Text.Replace(text_pattern.Text, text_replace.Text);
                label_operationStatus.Text = "Всё успешно заменено";
            }
        }
    }
}
